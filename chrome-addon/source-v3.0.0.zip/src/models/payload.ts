import { Command } from "./command"

export type Payload = {
  payload: Command
}
